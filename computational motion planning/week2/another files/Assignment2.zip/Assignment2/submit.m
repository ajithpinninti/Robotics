%% Script to test student's implementation of Module 2

function submit()

disp('Evaluating...');
evaluate();

end